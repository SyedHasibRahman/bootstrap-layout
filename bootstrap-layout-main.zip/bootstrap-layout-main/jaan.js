console.log(3);
console.log(77);
console.log(177);